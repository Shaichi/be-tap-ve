---
name: uml-bizcontext
description: Vẽ sơ đồ ngữ cảnh nghiệp vụ (business context diagram / DFD mức 0) ra draw.io – hình tròn trung tâm là hệ thống / doanh nghiệp, các thực thể bên ngoài xếp 2 cột trái/phải, mỗi luồng dữ liệu / thông tin là một mũi tên vuông góc riêng, tên luồng nằm ngang trên đoạn ngang – bố cục tự động không chồng hình, nhãn không đè đường. Dùng khi người dùng gọi /uml-bizcontext hoặc cần mô tả phạm vi nghiệp vụ cho người không làm kỹ thuật.
argument-hint: "<hệ thống / doanh nghiệp + các bên liên quan>"
user-invocable: true
---

# Vẽ sơ đồ ngữ cảnh nghiệp vụ (`/uml-bizcontext`)

**Yêu cầu:** $ARGUMENTS

Dòng trên trống hoặc chưa được thay bằng yêu cầu thật → dùng mô tả người dùng đã đưa trong hội thoại; chưa rõ
hệ thống nào thì hỏi lại một câu ngắn rồi mới vẽ.

Khác `/uml-context` (context diagram COMET dạng class «software system» – «external …», dùng cho thiết kế phần
mềm): sơ đồ này dành cho **nghiệp vụ** – hình tròn ở giữa, ngôn ngữ của người dùng cuối, không có stereotype kỹ
thuật.

**ENGINE** = `<skill>` — skill gốc [comet-uml-drawio](../../SKILL.md) (thư mục gốc skill, hai cấp trên file lệnh này,
`../..`), chứa `scripts/`, `examples/`, `references/`. Không viết XML hay toạ độ bằng tay: chỉ viết
**spec JSON**, script tự bố cục (không chồng/dính hình) và kiểm tra. Lưu spec + kết quả vào `./uml/` của thư mục
làm việc (tạo nếu chưa có) trừ khi người dùng chỉ định chỗ khác.

**Ngôn ngữ trên sơ đồ: mặc định tiếng Anh.** Mọi chữ hiện trên sơ đồ (`title`, tên phần tử, thuộc tính, thao
tác, nhãn quan hệ, message, guard, câu hỏi decision…) viết bằng tiếng Anh, kể cả khi người dùng mô tả bằng tiếng
Việt – tự dịch sang thuật ngữ tiếng Anh chuẩn. Chỉ dùng ngôn ngữ khác khi người dùng yêu cầu rõ (vd "vẽ bằng
tiếng Việt") → đặt `"lang": "vi"` trong spec (không đặt thì `comet_check` báo L1). Trả lời người dùng vẫn
bằng ngôn ngữ của họ.

## 1. Đọc bắt buộc (chưa đọc xong thì chưa viết spec)
- `<skill>/examples/shop_bizcontext.json` — khuôn chuẩn (1 hệ thống trung tâm, 6 bên ngoài, 13 luồng).
- `<skill>/references/spec-format.md` — mục *Context diagram nghiệp vụ*; `<skill>/references/uml-notation.md` —
  mục *Context diagram nghiệp vụ*.

## 2. Quy tắc
- `"diagram": "bizcontext"`, `"title"`.
- **Đúng 1** phần tử trung tâm `{"id", "type": "system", "name": "Online Sales System"}` (B1) — vẽ thành
  hình tròn ở giữa.
- Thực thể ngoài `{"id", "type": "external", "name": "Customer"}`: người, tổ chức, bộ phận, hệ thống khác trao đổi
  thông tin với hệ thống. Tự chia 2 cột trái/phải cho cân số luồng, giữ thứ tự `elements` từ trên xuống; ép
  cột bằng `"side": "left"` / `"right"` trên element.
- Luồng `{"from", "to", "label": "Purchase Order"}` — **danh từ** chỉ dữ liệu / chứng từ / thông tin (không phải
  hành động), mỗi luồng **có tên** và **một đầu là hệ thống trung tâm** (B2). **Mỗi luồng = 1 mũi tên riêng**
  (không gộp), thứ tự luồng trong spec = thứ tự từ trên xuống ở cạnh hộp. Mũi tên đi ngang ra từ cạnh hộp, tên
  luồng nằm ngang trên đoạn ngang (dễ đọc); các luồng ngang tầm hình tròn cắm thẳng vào hông, luồng cao hơn /
  thấp hơn gập vuông góc một lần cắm vào đỉnh / đáy, các đường gập lồng nhau → không cắt nhau, không nhãn nào
  đè đường/nhãn khác. Nhiều luồng thì hộp tự cao ra, hình tròn chỉ nới vừa đủ; mọi hộp
  cùng kích thước (theo hộp lớn nhất) – `"uniformSize": false` để mỗi hộp vừa nội dung riêng. Không vẽ khung ngoài
  (`"frame": true` nếu cần khung + tiêu đề). Tên luồng nên ngắn (≤ ~6 từ);
  dài quá 240px sẽ tự xuống dòng.
- Mỗi thực thể ngoài có ít nhất 1 luồng (B3). Luồng giữa hai thực thể ngoài nằm ngoài phạm vi – bỏ.

## 3. Chạy – sửa đến sạch
```bash
python "<skill>/scripts/uml2drawio.py" ./uml/bctx_<ten>.json -o ./uml/bctx_<ten>.drawio
python "<skill>/scripts/comet_check.py" --partial ./uml/bctx_<ten>.json
python "<skill>/scripts/preview_svg.py" ./uml/bctx_<ten>.drawio -o ./uml/bctx_<ten>.html --png
```
1. `uml2drawio.py` tự chạy validator hình học → phải **0 ERROR** (mã thoát 2 = còn lỗi: sửa spec, chạy lại).
2. `comet_check.py` → 0 ERROR và **sửa hết WARN** (B1–B3) trong spec rồi chạy lại.
3. **Mở ảnh** `./uml/bctx_<ten>.png` bằng công cụ đọc file (xem như ảnh) và tự soát: nhãn đọc được, không đè đường
   hay hình.

## 4. Giao
- Có tool draw.io MCP `open_drawio_xml` → đọc file `.drawio` vừa sinh, truyền **nguyên văn** vào `content`;
  không bật `postLayout`/auto-layout (phá bố cục).
- Không có MCP → đưa đường dẫn `./uml/bctx_<ten>.drawio` (+ `.png`).
- Báo trung thực số ERROR/WARN/INFO còn lại và lý do.

# Định dạng spec JSON cho `uml2drawio.py`

Một file có thể chứa: 1 spec (object), một mảng spec, hoặc `{"diagrams": [spec, ...]}`.
Mỗi spec → 1 trang draw.io. **Không có trường toạ độ** – bố cục hoàn toàn tự động. Thứ tự khai báo
phần tử/quan hệ được dùng để phá thế hoà khi xếp tầng/cột → khai báo theo thứ tự đọc mong muốn (vd lớp
trung tâm trước, quan hệ theo luồng chính trước).

## Trường cấp cao

| Trường | Bắt buộc | Ý nghĩa |
|---|---|---|
| `diagram` | ✔ | `usecase` · `context` · `class` · `communication` · `sequence` · `state` · `activity` · `component` · `deployment` · `package` · `erd` · `screenflow` · `bizcontext` |
| `title` | | Tên hiển thị trên khung (`uc Title`, `sd Title`...) |
| `lang` | | Ngôn ngữ chữ trên sơ đồ, mặc định `"en"` – mọi chữ viết tiếng Anh. Chỉ đặt `"vi"`… khi người dùng yêu cầu rõ ngôn ngữ khác (không đặt mà có chữ có dấu → L1) |
| `useCase` | tương tác | Tên use case mà communication/sequence hiện thực (khớp R1) |
| `stateMachineOf` | state | Tên lớp «state dependent control» (khớp R7/R8) |
| `system` | usecase | Tên hệ thống trên system boundary (mặc định = `title`) |
| `bundle` | mọi sơ đồ | Khoá namespace cho toàn bộ bộ diagram của cùng một hệ thống; nên đặt giống nhau cho tất cả spec. Khi có bundle, các luật consistency/traceability không mượn dữ liệu từ bundle khác; spec cũ không có bundle vẫn tương thích |
| `direction` | | `TB` (trên→dưới) hoặc `LR` (trái→phải). Mặc định `LR` cho usecase/communication/activity, `TB` còn lại |
| `frame` | | `false` để bỏ khung UML ngoài (bizcontext, screenflow sitemap, ERD Chen mặc định không khung – `true` để vẽ) |
| `autonumber` | | communication: tự đánh số message nếu thiếu `seq` (mặc định true); sequence: mặc định false |
| `elements` | ✔ | Danh sách phần tử |
| `relations` | | Danh sách quan hệ (không dùng cho sequence) |
| `messages` | tương tác | Message (communication, sequence) |
| `fragments` | | Combined fragment (sequence) |
| `level` | | `"design"` cho class/sequence/communication mức thiết kế (SDS: Controller/Service/Repository/DTO – mặc định Spring Boot, không stereotype COMET) – xem `comet-method.md` mục 5 (R3/R4/R10 bỏ qua, X8) |
| `activations` | | sequence: `true` → vẽ thanh activation (mở khi có message sync tới lifeline, đóng khi reply; self-call lồng thanh con) |
| `notation` | | erd: `"crowfoot"` → ERD crow's foot (khái niệm hoặc vật lý) thay cho Chen |
| `partitions` | | activity: danh sách làn (swimlane), chuỗi `"ATM"` hoặc `{"id": "atm", "name": "ATM"}`; thứ tự = thứ tự làn (TB: trái→phải, LR: trên→dưới) |

## Phần tử (`elements[]`)

Trường chung: `id` (mặc định = `name`; dùng trong `from`/`to`/`in`), `type`, `name`, `stereotype`
(chuỗi hoặc mảng; viết trần, không « »), `in` (id phần tử cha – lồng vào container),
`partition` (activity có `partitions`: id hoặc tên làn; phần tử không ghi sẽ theo làn của nút kề).
Semantic identity v2 (tuỳ chọn): `conceptId`/`semanticId`/`modelId` để trỏ tới cùng canonical concept xuyên diagram;
`aliases` để khai báo tên thay thế; `aliasOf` để biểu diễn rằng representation này là alias của concept đã biết.
Không dùng `id` diagram-local làm canonical identity.
Spec do `comet_project.py compile` sinh ra luôn mang `conceptId` trên phần tử concept, và `useCaseConceptId` /
`stateMachineOfConceptId` ở cấp spec khi `useCase` / `stateMachineOf` là concept → identity giữ nguyên khi đổi tên
(xem `references/comet-project.md`). Không sửa tay các spec này; sửa file canonical rồi compile lại.

| `type` | Trường riêng |
|---|---|
| `actor` | `side`: `"left"`/`"right"` (usecase: mặc định trái nếu là đầu `from` của association; communication: `"right"` = cột cuối, dùng cho hệ thống ngoài/actor phụ), `primary`: true; `stereotype` tuỳ chọn: `human actor`, `system actor`, `input device actor`, `output device actor`, `I/O device actor`, `timer actor` |
| `usecase` | – (tự nằm trong system boundary) |
| `class`, `entity`, `external`, `system`, `datatype`, `box` | `attributes[]`, `operations[]`, `abstract`: true (tên in nghiêng), `compartments`: true (luôn vẽ ngăn rỗng) |
| `interface` | như class (tự thêm «interface»); `notation: "lollipop"` → vẽ dạng ball (vòng tròn nhỏ + tên), dùng trong component diagram |
| `enumeration` | `literals[]` |
| `object` | `class`: tên lớp → hiển thị `name:Class` (không có `name` → `:Class`); lifeline UML 2 không gạch chân; `external`: true → không phải lớp của hệ thống (Client/Browser, hệ thống ngoài) – X8 bỏ qua |
| `state` | `activities[]` (vd `"entry / Display Welcome"`); con lồng qua `in` → composite state |
| `action` | (activity diagram) |
| `initial`, `final`, `activityFinal`, `flowFinal` | – |
| `choice`, `decision`, `merge` | `question` (hoặc `name`): câu hỏi điều kiện in trong thoi, vd `"Valid PIN?"` – thoi tự nới cho vừa chữ; `showName: false` để ẩn; `merge` chỉ in khi `showName: true` |
| `junction` | – |
| `fork`, `join` | `length` (mặc định 120) |
| `history`, `deephistory` | – |
| `note` | `text` |
| `component` | stereotype mặc định «component»; có thể chứa phần tử con |
| `node`, `device`, `executionEnvironment` | stereotype mặc định «node»/«device»/«execution environment»; chứa component/artifact |
| `artifact` | – |
| `package`, `subsystem` | chứa phần tử con qua `in` |
| `entity`, `table` (ERD) | Chen: chỉ `name`; `weak`: true (viền kép), không vẽ thuộc tính. Crow's foot: `entity` có `attributes[]` (vd `"+ Full Name"`); `table` có `columns[]` `{"name", "type", "pk", "fk", "nullable": false}` và `entity` (tên / mảng tên entity khái niệm mà bảng hiện thực, khớp X7) |
| `relationship` (ERD) | hình thoi quan hệ bậc 3+, `name`; nối bằng relation có `card` |
| `screen`, `page`, `dialog`, `popup` (screen flow) | chỉ `name`: màn hình = ô chữ nhật, popup/dialog = ô bo góc; `branch: "side"` (con toả từ cạnh phải), `side` (vị trí so với cha) |
| `system` (bizcontext) | hình tròn trung tâm – đúng 1 |

Context diagram: đúng 1 `{"type": "system", "stereotype": "software system"}` và các lớp ngoài
`{"type": "external", "stereotype": ...}` với `"external input device"` / `"external output device"` /
`"external I/O device"` / `"external user"` / `"external system"` / `"external timer"` (`type: "class"`
cũng được chấp nhận). Association có `label` ("Inputs to", "Outputs to", "Interacts with", "Awakens")
và `fromMult`/`toMult`; xem `examples/atm_context.json`.

Communication/sequence: đối tượng `type: "object"`, `class`, `stereotype` theo COMET
(`user interaction`, `input`, `output`, `proxy`, `state dependent control`, `coordinator`,
`business logic`, `entity`...). Cột được xếp tự động theo nhóm stereotype.

## Quan hệ (`relations[]`)

Trường chung: `type`, `from`, `to`, `label`/`name`, `id`. Bỏ trống `type` → mặc định theo loại sơ đồ: `activity` → `flow`, `state` → `transition`, `erd` → `relationship`, `screenflow` → `navigate`, còn lại → `association`.

| `type` | Trường riêng | Hướng `from → to` |
|---|---|---|
| `association` | `fromMult`, `toMult`, `fromRole`, `toRole`, `navigable` | bất kỳ; usecase: actor → use case |
| `aggregation`, `composition` | như association | **toàn thể → bộ phận** |
| `generalization` | – | **con → cha** |
| `realization` | – | lớp → interface (tới interface dạng lollipop = `provides`) |
| `provides` | – | component → interface lollipop: nét liền không mũi tên (provided interface) |
| `requires`, `usage` | – | component/lớp → interface hoặc supplier: nét đứt mũi tên mở + «use» (required interface) |
| `dependency` | `stereotype` | client → supplier |
| `include` | – | base → included |
| `extend` | `condition` | extension → base |
| `transition`, `flow` | `event`, `guard`, `action` (chuỗi hoặc mảng), hoặc `label` viết sẵn `"Ev [g] / a"` | nguồn → đích (cho phép `from == to`: self-transition) |
| `anchor` | – | note → phần tử |
| `communicationpath`, `connector` | `stereotype`, mult | node ↔ node |
| `link` | – | (communication – thường tự sinh từ messages) |
| (ERD) quan hệ | `name` (chữ trong hình thoi, bắt buộc), `fromCard`, `toCard`: `1` · `N` · `M`; `identifying: true` → hình thoi viền kép; nối vào phần tử hình thoi thì dùng `card` | thực thể → thực thể (hoặc thực thể ↔ hình thoi) |
| `navigate` (screen flow) | `side` (vị trí màn đích so với màn nguồn); không nhãn | màn nguồn → màn đích |
| (bizcontext) luồng | `label` / `data`: tên dữ liệu trao đổi; `type` bỏ trống hoặc `flow` | một đầu phải là `system` |

Quan hệ có thể nối phần tử ở các cấp lồng khác nhau (vd component trong node A → artifact trong node B).

## Message (`messages[]`)

| Trường | Ý nghĩa |
|---|---|
| `from`, `to` | id phần tử (sequence: nếu id chưa khai báo sẽ tự tạo object `:id`) |
| `name` | tên message (bắt buộc trừ reply) |
| `seq` | số thứ tự: `"1"`, `"2"`, `"10a"`, `"1.2"`... |
| `type` | sequence: `sync` (mặc định) · `async` · `reply` · `create` |
| `id` | sequence: dùng để tham chiếu trong fragment |

- Communication: các message giữa cùng một cặp đối tượng gộp trên 1 link; mũi tên nhỏ →/←/↑/↓
  được chọn theo hướng thật sau bố cục.
- Sequence: thứ tự dọc = thứ tự trong mảng. `from == to` → self message.

## Fragment (`fragments[]`, chỉ sequence)

```json
{"type": "alt", "operands": [
  {"guard": "PIN valid", "from": "m10", "to": "m11"},
  {"guard": "else",      "from": "m12", "to": "m13"}]}
```
- `type`: `alt`, `opt`, `loop`, `par`, `break`, `critical`, `neg`, `ref`...; `label` để ghi đè
  (vd `"loop [1..3]"`).
- Dạng 1 operand rút gọn: `{"type": "loop", "guard": "more items", "from": "m3", "to": "m6"}`.
- Fragment lồng nhau được tự phát hiện nếu khoảng message nằm trọn trong fragment khác.

## Ví dụ ngắn

```json
{
  "diagram": "usecase", "title": "ATM", "system": "Banking System",
  "elements": [
    {"id": "cust", "type": "actor", "name": "ATM Customer"},
    {"id": "bank", "type": "actor", "name": "Bank Server", "side": "right"},
    {"id": "wd", "type": "usecase", "name": "Withdraw Funds"},
    {"id": "vp", "type": "usecase", "name": "Validate PIN"}
  ],
  "relations": [
    {"type": "association", "from": "cust", "to": "wd"},
    {"type": "association", "from": "wd", "to": "bank"},
    {"type": "include", "from": "wd", "to": "vp"}
  ]
}
```

### Activity diagram có swimlane

```json
{
  "diagram": "activity", "title": "Withdraw Funds",
  "partitions": ["ATM Customer", "ATM", "Bank Server"],
  "elements": [
    {"id": "start", "type": "initial", "partition": "ATM Customer"},
    {"id": "insert", "type": "action", "name": "Insert Card", "partition": "ATM Customer"},
    {"id": "validate", "type": "action", "name": "Validate PIN", "partition": "Bank Server"},
    {"id": "d1", "type": "decision", "partition": "Bank Server"},
    {"id": "menu", "type": "action", "name": "Display Menu", "partition": "ATM"},
    {"id": "invalid", "type": "action", "name": "Display Invalid PIN", "partition": "ATM"},
    {"id": "m1", "type": "merge", "partition": "ATM"},
    {"id": "eject", "type": "action", "name": "Eject Card", "partition": "ATM"},
    {"id": "end", "type": "activityFinal", "partition": "ATM Customer"}
  ],
  "relations": [
    {"type": "flow", "from": "start", "to": "insert"},
    {"type": "flow", "from": "insert", "to": "validate"},
    {"type": "flow", "from": "validate", "to": "d1"},
    {"type": "flow", "from": "d1", "to": "menu", "guard": "PIN valid"},
    {"type": "flow", "from": "d1", "to": "invalid", "guard": "PIN invalid"},
    {"type": "flow", "from": "menu", "to": "m1"},
    {"type": "flow", "from": "invalid", "to": "m1"},
    {"type": "flow", "from": "m1", "to": "eject"},
    {"type": "flow", "from": "eject", "to": "end"}
  ]
}
```
- Mọi luồng ra khỏi `decision` phải có `guard` (tối đa một `"else"`); song song dùng `fork` … `join`.
- Hai nhánh gặp lại nhau → **gộp bằng `merge`** rồi mới vào action: action có ≥ 2 luồng vào là join ngầm
  (chờ đủ mọi luồng → nhánh rẽ từ decision bị kẹt), comet_check báo A6. comet_check A1–A6 kiểm tra các luật này.
- Vòng lặp (luồng quay lui) được phép — quay về một `merge` đặt trước action cần lặp; script tự vẽ vào góc hình
  thoi, không đè luồng khác.

### Component diagram với provided/required interface

```json
{"id": "ibank", "type": "interface", "name": "IBankService", "notation": "lollipop"}
{"type": "provides", "from": "bankService", "to": "ibank"}
{"type": "requires", "from": "atmClient", "to": "ibank"}
```

Ví dụ đầy đủ cho mọi loại COMET: thư mục `examples/` (hệ ATM/Banking của Gomaa), gồm cả
`atm_activity_withdraw.json` (swimlane), `banking_component.json`, `banking_package.json`.

### ERD (ký pháp Chen)

Thực thể chỉ có tên, quan hệ là hình thoi có tên, bản số `1` / `N` / `M` ở đầu nối phía thực thể:
```json
{"diagram": "erd", "title": "LMS", "elements": [
  {"id": "user", "type": "entity", "name": "User"},
  {"id": "role", "type": "entity", "name": "Role"},
  {"id": "comment", "type": "entity", "name": "Comment"}],
 "relations": [
  {"from": "role", "to": "user", "name": "has_role", "fromCard": "M", "toCard": "N"},
  {"from": "user", "to": "comment", "name": "comments", "fromCard": "1", "toCard": "N"},
  {"from": "comment", "to": "comment", "name": "replies", "fromCard": "1", "toCard": "N"}]}
```
- Mỗi relation sinh 1 hình thoi ghi `name` ở giữa 2 thực thể; `fromCard` ghi cạnh `from`, `toCard` cạnh `to`.
  `from` = `to` → quan hệ đệ quy. `identifying: true` → hình thoi viền kép.
- Quan hệ bậc 3+: phần tử `{"id": "r", "type": "relationship", "name": "..."}` + relation
  `{"from": "<entity>", "to": "r", "card": "N"}` cho từng thực thể.
- Không vẽ thuộc tính (`attributes` bị bỏ qua kèm cảnh báo). `weak: true` → viền kép; không khung/tiêu đề (bật
  bằng `frame: true`).
- Bản số hợp lệ: `1`, `N`, `M`, `P` (chữ hoa) hoặc `(min,max)` như `(0,N)`, `(1,1)`. Thực thể `weak` phải có ít
  nhất một quan hệ `identifying: true` tới thực thể chủ (E5).
- Ví dụ đầy đủ: `examples/elearn_erd.json`. comet_check E1–E3, E5.

### ERD crow's foot (`"notation": "crowfoot"`)

Dùng cho SRS (ERD khái niệm) và SDS (Database Design vật lý). Bản số ở hai đầu: `1`, `0..1`, `1..N`, `0..N`
(`N`/`M`/`*` = many). Khái niệm – thực thể có thuộc tính nghiệp vụ, quan hệ đặt tên bằng động từ -ing:
```json
{"diagram": "erd", "notation": "crowfoot", "bundle": "talenthub", "title": "TalentHub - ERD", "elements": [
  {"id": "user", "type": "entity", "name": "User", "attributes": ["+ Full Name", "+ Email"]},
  {"id": "job", "type": "entity", "name": "Job Posting", "attributes": ["+ Title", "+ Status"]}],
 "relations": [
  {"from": "user", "to": "job", "name": "creating (HR Manager)", "fromCard": "1", "toCard": "0..N"}]}
```
Vật lý – bảng có cột kiểu dữ liệu, `pk`/`fk`/`nullable`, `entity` trỏ về ERD khái niệm cùng `bundle` (X7);
quan hệ giữa hai bảng không cần tên:
```json
{"diagram": "erd", "notation": "crowfoot", "bundle": "talenthub", "title": "TalentHub - Database Design", "elements": [
  {"id": "users", "type": "table", "name": "users", "entity": "User", "columns": [
    {"name": "id", "type": "bigserial", "pk": true},
    {"name": "email", "type": "varchar(255)", "nullable": false}]},
  {"id": "jobs", "type": "table", "name": "jobs", "entity": "Job Posting", "columns": [
    {"name": "id", "type": "bigserial", "pk": true},
    {"name": "created_by", "type": "bigint", "fk": true, "nullable": false}]}],
 "relations": [{"from": "users", "to": "jobs", "fromCard": "1", "toCard": "0..N"}]}
```
- Mặc định `direction: LR`. Cột hiển thị `PK id: bigserial NOT NULL`, `FK created_by: bigint NOT NULL`.
- Ví dụ đầy đủ: `examples/talenthub_erd_conceptual.json`, `examples/talenthub_erd_physical.json`. comet_check
  E1–E4, X7, X9.
- Cột có thể thêm `"values": ["PENDING", "CONFIRMED"]` (tập giá trị cột status/enum – P11 so với state của statechart, data dictionary in ra), `"description"` (mô tả trong data dictionary) và `"ref": "users.id"` (bảng đích của FK khi không
  suy được từ tên cột). Data dictionary: `scripts/comet_datadict.py <spec ERD vật lý> -o <file>.md`.

### Sequence mức thiết kế (SDS)

```json
{"diagram": "sequence", "level": "design", "activations": true, "autonumber": true, "bundle": "talenthub",
 "title": "Register Account - Sequence", "useCase": "Register Account", "elements": [
  {"id": "cl", "type": "object", "name": "React Web App", "external": true},
  {"id": "ctl", "type": "object", "class": "AuthController"},
  {"id": "svc", "type": "object", "class": "UserServiceImpl"}],
 "messages": [
  {"from": "cl", "to": "ctl", "name": "register(RegisterRequest)"},
  {"from": "ctl", "to": "svc", "name": "register(RegisterRequest)"},
  {"from": "svc", "to": "svc", "name": "validateEmailNotTaken(String)"},
  {"from": "svc", "to": "ctl", "name": "UserResponse", "type": "reply"},
  {"from": "ctl", "to": "cl", "name": "201 Created (UserResponse)", "type": "reply"}]}
```
Lớp của lifeline (`class`) phải có trong class diagram `"level": "design"` cùng `bundle` (X8).

### Screen flow (sơ đồ trang / site map)

Cây điều hướng toàn hệ thống từ Home: ô chỉ ghi tên màn hình, popup bo góc, mũi tên mở không nhãn, không khung:
```json
{"diagram": "screenflow", "title": "LMS", "root": "home", "elements": [
  {"id": "home", "type": "screen", "name": "Home"},
  {"id": "login", "type": "popup", "name": "User Login"},
  {"id": "posts", "type": "screen", "name": "Post Lists"},
  {"id": "post", "type": "screen", "name": "Post Details"},
  {"id": "addpost", "type": "screen", "name": "Add Post"}],
 "relations": [
  {"from": "home", "to": "login", "side": "left"},
  {"from": "home", "to": "posts"},
  {"from": "posts", "to": "post"},
  {"from": "posts", "to": "addpost"}]}
```
- Chỉ có `screen`/`page` (ô chữ nhật) và `popup`/`dialog` (ô bo góc). Không có initial/final/decision, không
  `items`, mũi tên không `trigger`/`guard`/`label` — nếu có sẽ bị bỏ qua kèm cảnh báo (comet_check F2).
- `root`: gốc (mặc định nút đầu tiên không có mũi tên vào). Cạnh cây = lần đầu một nút được trỏ tới theo thứ tự
  relations; cạnh còn lại (vd. Course Details → Course Register) tự đi vòng tránh hình.
- `side` (trên relation hoặc element con): `same` cùng hàng (mặc định cho con đầu tiên), `down` hàng dưới, ra từ
  đáy cha (mặc định cho các con sau), `up` hàng trên, `top` ngay trên đầu cha, `left` cột bên trái (ghép
  `left-up`, `left-down`).
- `branch: "side"` trên element cha → con toả từ cạnh phải thay vì từ đáy. `frame: true` → vẽ lại khung + tiêu đề.
- Ví dụ đầy đủ: `examples/lms_screenflow_sitemap.json`. comet_check F1–F2.

### Context diagram nghiệp vụ

```json
{"diagram": "bizcontext", "title": "Online Store – Context", "elements": [
  {"id": "shop", "type": "system", "name": "Sales System"},
  {"id": "kh", "type": "external", "name": "Customer"}],
 "relations": [
  {"from": "kh", "to": "shop", "label": "Purchase Order"},
  {"from": "shop", "to": "kh", "label": "Invoice"}]}
```
Hệ thống là hình tròn giữa; thực thể ngoài xếp 2 cột trái/phải (tự chia cân số luồng theo thứ tự `elements`,
ép bằng `"side": "left"|"right"` trên element), cột căn giữa theo hình tròn. **Mỗi relation là 1 mũi tên
vuông góc riêng** (không gộp): đi ngang ra từ cạnh hộp, tên luồng nằm ngang trên đoạn ngang; luồng ngang tầm cắm
thẳng vào hông hình tròn, luồng cao hơn / thấp hơn gập một lần cắm vào đỉnh / đáy, các đường gập lồng nhau nên không cắt nhau.
Mọi hộp thực thể ngoài cùng kích thước (rộng theo tên dài nhất, cao theo hộp nhiều luồng nhất); `"uniformSize": false`
ở cấp spec → mỗi hộp vừa nội dung riêng. Mặc định không có khung ngoài (`"frame": true` để vẽ khung + tiêu đề). Bán kính hình tròn (nhỏ nhất xếp được) và khoảng cách cột tự nới tới khi không nhãn nào đè hình/đường/nhãn. `relations` có thể thay bằng `flows`. Ví dụ: `examples/shop_bizcontext.json`.
comet_check B1–B3.
